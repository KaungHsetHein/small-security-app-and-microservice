package com.example.authserverdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthServerDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
