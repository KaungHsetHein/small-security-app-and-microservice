package com.example.authserverdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthServerDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(AuthServerDemoApplication.class, args);
    }

}
